<?php

namespace App\Traits;

use App\Models\Device;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

trait NotificationTrait
{

    public function sendNotificationOnTpHitting($signal, $tp)
    {
        $type = 'signalInfo';

        $input["content"] = "The value $tp is hitting in $signal->currency_pair.";
        $this->sendToAllUsers($input, null, $type);
        return true;
    }

    public function sendNotificationOnSLHitting($signal, $sl)
    {
        $type = 'signalInfo';

        $input["content"] = "The value $sl is hitting in $signal->currency_pair.";
        $this->sendToAllUsers($input, null, $type);
        return true;
    }
    public function sendOpeningPriceNotification($postSignal)
    {
        $type = 'signalInfo';
        $input["content"] = "Open price of new signal $postSignal->currency_pair is $postSignal->open_price.";
        $this->sendToAllUsers($input, null, $type);
        return true;
    }

    public function sendToAllUsers($input, $ids, $type)
    {

        if (Auth::user()) {
            $users = User::where('is_notification', true)->where('id', '!=', Auth::user()->id)->pluck('id');
        } else {
            $users = User::where('is_notification', true)->pluck('id');
        }

        $data["message"] = $input['content'];
        $checkResponse = Device::sendPush($data, $users, $type);
        return true;
    }


    public function createNotification($input)
    {
        // $notification = new Notification();
        // if (isset($input['id']))
        //     $notification = Notification::where('id', $input['id'])->first();

        // $notification->content = $input['content'];
        // $notification->type = 'info';
        // $notification->save();
    }
}
